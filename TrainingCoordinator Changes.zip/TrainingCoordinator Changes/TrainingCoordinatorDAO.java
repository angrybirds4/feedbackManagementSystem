package com.cg.fbms.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.fbms.dto.Employee;
import com.cg.fbms.dto.Faculty;
import com.cg.fbms.dto.TrainingProgram;
import com.cg.fbms.utility.JPAUtility;

public class TrainingCoordinatorDAO implements ITrainingCoordinatorDAO {

	EntityManagerFactory  factory = JPAUtility.getFactory();
	EntityManager manager = factory.createEntityManager();
	EntityTransaction transaction = manager.getTransaction();
	
	@Override
	public List<TrainingProgram> showTrainingCourse() throws Exception {
		
		String queryAllRows = "SELECT r from TrainingProgram r";
		TypedQuery<TrainingProgram> query = manager.createQuery(queryAllRows, TrainingProgram.class);
		List<TrainingProgram> trainingsList = query.getResultList();
		if(trainingsList == null || trainingsList.size() == 0) {
			throw new Exception("No data Found...");
		}
		return trainingsList;
	}
	
	@Override
	public boolean addTrainingCourse(TrainingProgram TrainingP) {
		//transaction
		transaction.begin();
		try {
			manager.persist(TrainingP);
			transaction.commit();
			return true;
		}
		catch (Exception e) {
			
			transaction.rollback();
			return false;
		}
		finally {
			manager.close();
			}
	}
	
	@Override
	public TrainingProgram findTrainingCourse(int id) {
		TrainingProgram training = manager.find(TrainingProgram.class, id);
		return training;
	}
	
	@Override
	public Boolean updateTrainingCourse(TrainingProgram training) {
		transaction.begin();
		manager.merge(training);
		transaction.commit();
		return true;
	}

	@Override
	public Boolean deleteTrainingCourse(int trainingId) {
		
		try {
			transaction.begin();
			TrainingProgram training = manager.find(TrainingProgram.class, trainingId);
			manager.remove(training);
			transaction.commit();
			return true;
		}
		catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public Boolean validateDuplicate(TrainingProgram trainingP) {
	
		int duplicateCount=0;
		String queryAllRows = "SELECT r from TrainingProgram r";
		TypedQuery<TrainingProgram> query = manager.createQuery(queryAllRows, TrainingProgram.class);
		List<TrainingProgram> trainingsList = query.getResultList();
		for(TrainingProgram trainingIterator: trainingsList) {
			if(trainingIterator.getCourseId()==trainingP.getCourseId()&&
					trainingIterator.getFacultyId()==trainingP.getFacultyId()
					)
			{
				if(trainingIterator.getTrainingStartDate().getDate()==trainingP.getTrainingStartDate().getDate()&&
						trainingIterator.getTrainingStartDate().getMonth()==trainingP.getTrainingStartDate().getMonth()&&
						trainingIterator.getTrainingStartDate().getYear()==trainingP.getTrainingStartDate().getYear()) 
				{
					
					if(trainingIterator.getTrainingEndDate().getDate()==trainingP.getTrainingEndDate().getDate()&&
						trainingIterator.getTrainingEndDate().getMonth()==trainingP.getTrainingEndDate().getMonth()&&
						trainingIterator.getTrainingEndDate().getYear()==trainingP.getTrainingEndDate().getYear())
					{
						duplicateCount++;
			
						break;
					}
				}
			}
			System.out.println(trainingIterator.getTrainingStartDate().getDate()+"  "+trainingP.getTrainingStartDate().getDate());
		}
		System.out.println(duplicateCount);
		if(duplicateCount>0)
			return false;
		else
			return true;
	}
}


