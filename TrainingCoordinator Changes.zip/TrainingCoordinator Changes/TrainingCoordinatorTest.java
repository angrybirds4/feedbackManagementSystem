package com.cg.fbms.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.cg.fbms.dto.TrainingProgram;
import com.cg.fbms.service.ITrainingCoordinatorService;
import com.cg.fbms.service.TrainingCoordinatorService;

public class TrainingCoordinatorTest {

	ITrainingCoordinatorService service = new TrainingCoordinatorService();
	
	
	@Test
	public void addTrainingSessionTest() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = null;
		Date endDate = null;
		try {
			startDate = format.parse("2018-02-26");
			endDate = format.parse("2019-03-26");
		} catch (ParseException e) {
			
			e.printStackTrace();
		}

		TrainingProgram training = new TrainingProgram(1569,5866,startDate,endDate);
		assertTrue(service.addTrainingSession(training));
	}
	
	@Test
	public void showTrainingSessionTest() {
		List<TrainingProgram> trainingList = new ArrayList<TrainingProgram>();
		trainingList = service.showTrainingCourse();
		assertTrue(trainingList.size()>0);
	}
	
	@Test
	public void findTrainingSessionTest() {
		TrainingProgram training = service.findTrainingSession(1190);
		assertEquals(5222, training.getCourseId());
	}
	
	@Test
	public void updateTrainingSessionTest() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = null;
		Date endDate = null;
		try {
			startDate = format.parse("2018-02-26");
			endDate = format.parse("2019-03-26");
		} catch (ParseException e) {
			
			e.printStackTrace();
		}

		TrainingProgram training = service.findTrainingSession(1191);
		training.setCourseId(2055);
		training.setFacultyId(5126);
		training.setTrainingStartDate(startDate);
		training.setTrainingEndDate(endDate);
		
		assertTrue(service.updateTrainingSession(training));
	}
	
	@Test
	public void validateDuplicateTest() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = null;
		Date endDate = null;
		try {
			startDate = format.parse("2018-08-20");
			endDate = format.parse("2019-09-26");
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		TrainingProgram training = new TrainingProgram(52,22,startDate,endDate);
	}
	
	@Test
	public void deleteTrainingSessionTest()
	{
		
		assertTrue(service.deleteTrainingSession(1205));
	}
}
